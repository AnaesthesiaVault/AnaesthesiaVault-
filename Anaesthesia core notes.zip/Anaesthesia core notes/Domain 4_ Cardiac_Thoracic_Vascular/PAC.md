---
Domain: "04"
Subdomain:
  - Equipment
Date: 2024-06-11
tags: [PAC, Pulmonary-arterial-catheter]
Date modified: Friday, October 4th 2024, 4:57:36 pm
---

# Links
- [[Central venous pressure (CVP)]]

---

---

Dr. Francois Uys. Anaesthesia registrar

Department of Anaesthesia and Perioperative medicine. University of Cape Town

**Tags:**

Dr. Francois Uys. Anaesthesia registrar

Department of Anaesthesia and Perioperative medicine. University of Cape Town

**References:**

1. ICU One Pager. (2024). Retrieved June 5, 2024, from [https://onepagericu.com/](https://onepagericu.com/)
**Summary or mindmap:**
[ICU_one_pager_PAC.pdf (squarespace.com)](https://static1.squarespace.com/static/5e6d5df1ff954d5b7b139463/t/5e82d61ce78b6956d2cf8deb/1585632796519/ICU_one_pager_PAC.pdf)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
