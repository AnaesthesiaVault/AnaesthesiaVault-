---
Domain: "04"
Subdomain:
  - Thoracic Anaesthesia
  - Medical
Date: 2024-03-18
tags: [Restrictive-lung-disease]
Date modified: Friday, October 4th 2024, 4:57:40 pm
---

# Summary

![](Pasted%20image%2020240314170251.png)

# Links
- [[Lung function testing]]
- [[Ventilation and Weaning]]

---

---
**References:**

**Summary or mindmap:**

---------------------------------------------------------------------------------------------


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
