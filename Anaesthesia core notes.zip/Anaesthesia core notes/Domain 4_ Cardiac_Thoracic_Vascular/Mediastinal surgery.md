---
Domain: "04"
Subdomain:
  - Thoracic Anaesthesia
Date: 2024-09-11
tags: [Mediastinal-surgery]
Date modified: Friday, October 4th 2024, 4:57:34 pm
---

# Links
- [[Lung resection]]
- [[Transplants and organ donation]]
- [[Double lumen and Bronchial blocker]]
- [[One lung Ventilation and VATS]]

---

---
**References:**

**Summary or mindmap:**

Videos

[Mediastinal anatomy](https://www.youtube.com/watch?v=JJn-KgKznu4)

[Anaesthesia for mediastinal surgery](https://www.youtube.com/watch?v=Ps1lwLZQndM&embeds_referring_euri=https%3A%2F%2Fcardiothoracicanaesthesia.com%2F&source_ve_path=Mjg2NjY)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
