---
{}
Date modified: Friday, October 4th 2024, 4:59:33 pm
tags: [NMJ]
---

Dr. Francois Uys. Anaesthesia registrar

Department of Anaesthesia and Perioperative medicine. University of Cape Town

Date: 2024-02-27

Time: 14:07

**Domain:** 05

**Subdomain:** NMJ

**Tags:**

**Associated links and tags:**

**References:**

**Summary or mindmap:**

---------------------------------------------------------------------------------------------

![](Pasted%20image%2020240227140724.png)

---


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
