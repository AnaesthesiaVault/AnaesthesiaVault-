---
Domain: "02"
Subdomain:
  - General
Date: 2024-04-16
tags: [Prolonged-operations]
Date modified: Friday, October 4th 2024, 4:58:09 pm
---

Dr. Francois Uys. Anaesthesia registrar

Department of Anaesthesia and Perioperative medicine. University of Cape Town

**Tags:**

**References:**

**Summary or mindmap:**

---------------------------------------------------------------------------------------------

![](Pasted%20image%2020240314164459.png)

---


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
