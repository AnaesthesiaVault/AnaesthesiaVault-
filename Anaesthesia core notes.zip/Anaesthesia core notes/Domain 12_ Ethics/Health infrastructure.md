---
Domain: "12"
Subdomain:
  - Management
Date: 2024-05-08
tags: [Infrastructure]
Date modified: Friday, October 4th 2024, 4:56:09 pm
---

# Approach to Health Care System Problems

Identification of problem

Immediate patient safety

Systematic review (latent/ contributory/ active failures)

Audit cycle

---

---
**References:** [Western cape government]

**Summary or mindmap:**

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
