---
Domain: "08"
Subdomain:
  - Equipment
Date: 2024-07-07
tags: [ICD]
Date modified: Friday, October 4th 2024, 4:59:57 pm
---

# Links
- [[Anaesthesia equipment]]

---

---
**References:**

1. ICU One Pager. (2024). Retrieved June 5, 2024, from [https://onepagericu.com/](https://onepagericu.com/)
**FRCA Mind Map Link:**
[ICU OP- ICD](https://static1.squarespace.com/static/5e6d5df1ff954d5b7b139463/t/5f00e10e782f302e6bfbec81/1593893136673/ICU_one_pager_chest_tubes.pdf)

---------------------------------------------------------------------------------------------


---

**Copyright**
© 2022 Francois Uys. All Rights Reserved.
